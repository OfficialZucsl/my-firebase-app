
'use client';

import { useState, useEffect } from 'react';
import { useFormStatus } from 'react-dom';
import { register } from '@/app/auth/actions';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import FiduciaLendLogo from '@/components/fiducia-lend-logo';
import Link from 'next/link';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { AlertCircle } from 'lucide-react';
import { onAuthStateChanged } from 'firebase/auth';
import { auth } from '@/lib/firebase';
import { useRouter } from 'next/navigation';

export default function SignupPage() {
  const [errorMessage, setErrorMessage] = useState<string | undefined>(undefined);
  const router = useRouter();

  useEffect(() => {
    // This effect handles creating the session cookie after a successful registration.
    // The `register` server action sets a temporary cookie 'login_success'.
    const wasRegistrationSuccessful = document.cookie.includes('login_success=true');
    
    if (wasRegistrationSuccessful) {
      const unsubscribe = onAuthStateChanged(auth, async (user) => {
        if (user) {
          try {
            // Unsubscribe immediately to prevent multiple runs
            unsubscribe();
            
            const idToken = await user.getIdToken();
            const response = await fetch('/api/auth/session', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ idToken }),
            });

            if (!response.ok) {
              throw new Error('Failed to create session on the server.');
            }

            // Clear the temporary cookie
            document.cookie = 'login_success=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;';
            
            // The AuthProvider will handle the redirect to '/', but we can push here as well
            // to ensure a swift navigation.
            router.push('/'); 
            
          } catch (error) {
            // If session creation fails, send them to the login page to try manually.
             setErrorMessage('Could not log you in automatically. Please try logging in.');
             router.push('/login');
          }
        }
      });
      return () => unsubscribe();
    }
  }, [router]);


  const handleSubmit = async (formData: FormData) => {
    setErrorMessage(undefined);
    const result = await register(formData);
    if (result?.error) {
      setErrorMessage(result.error);
    }
    // No redirect here. The useEffect handles it after the form action completes
    // and the page reloads.
  };

  return (
    <main className="flex items-center justify-center min-h-screen bg-background">
      <Card className="mx-auto max-w-sm w-full">
        <CardHeader className="space-y-2 text-center">
          <div className="flex justify-center">
             <FiduciaLendLogo className="size-12 text-primary" />
          </div>
          <CardTitle className="text-2xl">Create an Account</CardTitle>
          <CardDescription>Enter your information to create an account</CardDescription>
        </CardHeader>
        <CardContent>
          <form action={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Full Name</Label>
              <Input id="name" name="name" placeholder="John Doe" required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input id="email" name="email" type="email" placeholder="m@example.com" required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input id="password" name="password" type="password" required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="confirmPassword">Confirm Password</Label>
              <Input id="confirmPassword" name="confirmPassword" type="password" required />
            </div>
            {errorMessage && (
                <Alert variant="destructive">
                    <AlertCircle className="h-4 w-4" />
                    <AlertTitle>Signup Failed</AlertTitle>
                    <AlertDescription>{errorMessage}</AlertDescription>
                </Alert>
            )}
            <SignupButton />
          </form>
           <div className="mt-4 text-center text-sm">
            Already have an account?{' '}
            <Link href="/login" className="underline">
              Login
            </Link>
          </div>
        </CardContent>
      </Card>
    </main>
  );
}

function SignupButton() {
  const { pending } = useFormStatus();
  return (
    <Button type="submit" className="w-full" aria-disabled={pending}>
      {pending ? 'Creating Account...' : 'Create Account'}
    </Button>
  );
}
